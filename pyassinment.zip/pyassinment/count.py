no_line=0
num_chars=0
with open("story.txt", 'rt') as c:
    for line in c:
        no_line +=1
        num_chars += len(line)
print('Total no of line:',no_line)
print('total charector in file',num_chars)        
    