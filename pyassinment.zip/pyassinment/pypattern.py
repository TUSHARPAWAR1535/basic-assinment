
# 1st Program

for i in range (1,4):
    for j in range(1,i):
        print(" *",end="")
    print()    
    
for i in range (1,4):
    for j in range(4,i,-1):
        print(" *",end="")
    print()  
    
# 2nd Program
    
for b in range (1,7):
    for c in range(1,b):
        print(" *",end="")
    print()    
    
for b in range (1,7):
    for c in range(7,b,-1):
        print(" *",end="")
    print()           
       