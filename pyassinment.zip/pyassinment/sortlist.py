import numbers

number=[12,23,11,3,5,55]
for i in range(len(number)):
    for j in range(len(number)):
        if number[i]<number[j]:
            number[i],number[j]=number[j],number[i]
print(number)
